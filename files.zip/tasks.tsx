import { Action, ActionPanel, Alert, Color, Icon, Keyboard, List, confirmAlert, showToast, Toast } from "@raycast/api";
import { useEffect, useMemo, useState } from "react";
import { EditItem } from "./components/edit-item";
import { Item, loadItems, matches, parse, saveItems } from "./lib/store";

const ALL = "__all__";

export default function Tasks() {
  const [items, setItems] = useState<Item[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchText, setSearchText] = useState("");
  const [project, setProject] = useState(ALL);
  const [showDone, setShowDone] = useState(false);

  useEffect(() => {
    loadItems().then((stored) => {
      setItems(stored);
      setIsLoading(false);
    });
  }, []);

  async function commit(next: Item[]) {
    setItems(next);
    await saveItems(next);
  }

  const projects = useMemo(() => {
    const names = new Set<string>();
    for (const item of items) if (item.project) names.add(item.project);
    return [...names].sort();
  }, [items]);

  const visible = useMemo(
    () =>
      items.filter(
        (item) =>
          (showDone || item.status === "todo") &&
          (project === ALL || item.project === project) &&
          matches(item, searchText),
      ),
    [items, showDone, project, searchText],
  );

  async function capture() {
    const text = searchText.trim();
    if (text.length === 0) return;
    const item = parse(text);
    if (project !== ALL && !item.project) item.project = project;
    await commit([item, ...items]);
    setSearchText("");
  }

  async function toggle(item: Item) {
    const done = item.status === "todo";
    await commit(
      items.map((candidate) =>
        candidate.id === item.id
          ? { ...candidate, status: done ? "done" : "todo", doneAt: done ? Date.now() : undefined }
          : candidate,
      ),
    );
    await showToast({ style: Toast.Style.Success, title: done ? "Done" : "Back on the list" });
  }

  async function remove(item: Item) {
    const confirmed = await confirmAlert({
      title: "Delete this item?",
      message: item.title,
      primaryAction: { title: "Delete", style: Alert.ActionStyle.Destructive },
    });
    if (confirmed) await commit(items.filter((candidate) => candidate.id !== item.id));
  }

  async function clearDone() {
    const remaining = items.filter((item) => item.status === "todo");
    const removed = items.length - remaining.length;
    if (removed === 0) return;
    await commit(remaining);
    await showToast({ style: Toast.Style.Success, title: `Cleared ${removed}` });
  }

  const sharedActions = (
    <>
      <Action
        title={showDone ? "Hide Done Items" : "Show Done Items"}
        icon={showDone ? Icon.EyeDisabled : Icon.Eye}
        shortcut={{ modifiers: ["cmd", "shift"], key: "d" }}
        onAction={() => setShowDone(!showDone)}
      />
      <Action
        title="Clear Done Items"
        icon={Icon.Trash}
        style={Action.Style.Destructive}
        shortcut={{ modifiers: ["cmd", "shift"], key: "backspace" }}
        onAction={clearDone}
      />
    </>
  );

  return (
    <List
      isLoading={isLoading}
      filtering={false}
      searchText={searchText}
      onSearchTextChange={setSearchText}
      searchBarPlaceholder="Type a thought, or search"
      searchBarAccessory={
        projects.length > 0 ? (
          <List.Dropdown tooltip="Project" value={project} onChange={setProject}>
            <List.Dropdown.Item title="All projects" value={ALL} />
            {projects.map((name) => (
              <List.Dropdown.Item key={name} title={name} value={name} />
            ))}
          </List.Dropdown>
        ) : undefined
      }
    >
      {searchText.trim().length > 0 && (
        <List.Section title="Capture">
          <List.Item
            icon={Icon.Plus}
            title={searchText.trim()}
            subtitle="Add to the list"
            actions={
              <ActionPanel>
                <Action title="Add to the List" icon={Icon.Plus} onAction={capture} />
                {sharedActions}
              </ActionPanel>
            }
          />
        </List.Section>
      )}

      <List.Section title={showDone ? "Everything" : "To Do"} subtitle={`${visible.length}`}>
        {visible.map((item) => (
          <List.Item
            key={item.id}
            icon={
              item.status === "done"
                ? { source: Icon.CheckCircle, tintColor: Color.Green }
                : { source: Icon.Circle, tintColor: Color.SecondaryText }
            }
            title={item.title}
            subtitle={item.description || undefined}
            accessories={accessoriesFor(item)}
            actions={
              <ActionPanel>
                <Action
                  title={item.status === "todo" ? "Mark Done" : "Move Back to to Do"}
                  icon={item.status === "todo" ? Icon.CheckCircle : Icon.Circle}
                  onAction={() => toggle(item)}
                />
                <Action.Push
                  title="Edit"
                  icon={Icon.Pencil}
                  shortcut={Keyboard.Shortcut.Common.Edit}
                  target={
                    <EditItem
                      item={item}
                      onSave={(updated) =>
                        commit(items.map((candidate) => (candidate.id === item.id ? updated : candidate)))
                      }
                    />
                  }
                />
                <Action.CopyToClipboard
                  title="Copy Title"
                  content={item.title}
                  shortcut={Keyboard.Shortcut.Common.Copy}
                />
                <Action
                  title="Delete"
                  icon={Icon.Trash}
                  style={Action.Style.Destructive}
                  shortcut={Keyboard.Shortcut.Common.Remove}
                  onAction={() => remove(item)}
                />
                {sharedActions}
              </ActionPanel>
            }
          />
        ))}
      </List.Section>

      <List.EmptyView
        icon={Icon.Dot}
        title={items.length === 0 ? "Nothing here yet" : "Nothing left"}
        description="Start typing to add something."
      />
    </List>
  );
}

function accessoriesFor(item: Item): List.Item.Accessory[] {
  const accessories: List.Item.Accessory[] = [];
  if (item.project) accessories.push({ tag: { value: item.project, color: Color.Blue } });
  if (item.tags.length > 0) accessories.push({ text: item.tags.map((tag) => `@${tag}`).join(" ") });
  return accessories;
}
