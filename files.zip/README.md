# Flow

One text box in, two statuses out. Built so that capturing a thought never requires
deciding where it goes.

## Run it

```bash
npm install
npm run dev
```

`npm run dev` registers the extension with your local Raycast and hot-reloads on save.
Leave it running while you're changing things. When you're happy, quit it — the
extension stays installed.

Then open Raycast → Settings → Extensions → Flow and assign a global hotkey to
**Capture**. That hotkey is the whole point; pick something you can hit without looking.

## The two commands

**Capture** — hotkey, type, Enter. No window renders, so it's as fast as Raycast itself.
Closes with a HUD confirmation and nothing else.

**Tasks** — the list. The search bar doubles as the capture box: type anything that
isn't a match and the top row becomes "Add to the list."

## Syntax

Everything is optional. A bare line of text is a perfectly good item.

```
fix deferred deep link on android #referral @bug
```

- First `#word` → project
- Any `@word`, and any later `#word` → tag
- Everything else → title

Description is deliberately not capturable inline. Add it later with `Cmd+E`, or never.

## Keys

| | |
|---|---|
| `Enter` | Mark done (or add, when capturing) |
| `Cmd+E` | Edit |
| `Cmd+Shift+C` | Copy title |
| `Ctrl+X` | Delete |
| `Cmd+Shift+D` | Show/hide done items |
| `Cmd+Shift+Backspace` | Clear all done items |

## Design decisions you may want to undo later

Done items are hidden by default and there is no count of them anywhere. The list only
ever shrinks. If you find yourself wanting a "completed today" view, add it — but notice
first whether wanting it is the same instinct that made Linear and Obsidian too heavy.

`Enter` marks done rather than opening a detail view. There is no detail view.

Data lives in Raycast's `LocalStorage` under the key `flow.items`, as a single JSON
array. It's trivial to swap for a file in `environment.supportPath` if you later want
it in a git repo or readable by other tools.

## Not included on purpose

No due dates, no priorities, no third status, no sync, no reminders. Each one is a
decision at capture time, which is the thing that breaks.
