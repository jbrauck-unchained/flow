import { LaunchProps, showHUD } from "@raycast/api";
import { addItem } from "./lib/store";

export default async function Capture(props: LaunchProps<{ arguments: { text: string } }>) {
  const text = props.arguments.text.trim();
  if (text.length === 0) {
    await showHUD("Nothing to capture");
    return;
  }

  const item = await addItem(text);
  await showHUD(item.project ? `Captured in ${item.project}` : "Captured");
}
